// Average of a list of numbers - Mayur Narzary, Roll no. 264057, Intg BS-MS Physics, 1st Sem
#include <iostream>
using namespace std;
int main() {
    int n; cout << "How many numbers? "; cin >> n;
    double a[n], sum = 0;
    cout << "Enter numbers: ";
    for (int i = 0; i < n; i++) { cin >> a[i]; sum += a[i]; }
    cout << "Average = " << sum / n << endl;
    return 0;
}

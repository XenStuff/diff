// Location of the largest number - Mayur Narzary, Roll no. 264057, Intg BS-MS Physics, 1st Sem
#include <iostream>
using namespace std;
int main() {
    int n; cout << "How many numbers? "; cin >> n;
    double a[n];
    cout << "Enter numbers: ";
    for (int i = 0; i < n; i++) cin >> a[i];
    int pos = 0;
    for (int i = 1; i < n; i++) if (a[i] > a[pos]) pos = i;
    cout << "Largest = " << a[pos] << " at index " << pos
         << " (position " << pos + 1 << ")" << endl;
    return 0;
}

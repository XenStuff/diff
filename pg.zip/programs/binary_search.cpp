// [Programme Name: Binary search execution, My full name: Mayur Narzary, Roll no. 264057, Programme: Intg Bs-Ms Physics]
#include <iostream>
using namespace std;
int main() {
    int n; cout << "How many numbers? "; cin >> n;
    double a[n];
    cout << "Enter numbers: ";
    for (int i = 0; i < n; i++) cin >> a[i];
    // binary search needs a sorted list
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (a[j] > a[j + 1]) { double t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; }
    cout << "Sorted list: ";
    for (int i = 0; i < n; i++) cout << a[i] << " ";
    double key; cout << "\nEnter number to search: "; cin >> key;
    int low = 0, high = n - 1, found = -1;
    while (low <= high) {
        int mid = (low + high) / 2;
        if (a[mid] == key) { found = mid; break; }
        else if (a[mid] < key) low = mid + 1;
        else high = mid - 1;
    }
    if (found >= 0) cout << key << " found at index " << found << " of the sorted list." << endl;
    else cout << key << " not found." << endl;
    return 0;
}

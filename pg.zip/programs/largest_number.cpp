// [Programme Name: Largest number in a list, My full name: Mayur Narzary, Roll no. 264057, Programme: Intg Bs-Ms Physics]
#include <iostream>
using namespace std;
int main() {
    int n; cout << "How many numbers? "; cin >> n;
    double a[n];
    cout << "Enter numbers: ";
    for (int i = 0; i < n; i++) cin >> a[i];
    double max = a[0];
    for (int i = 1; i < n; i++) if (a[i] > max) max = a[i];
    cout << "Largest = " << max << endl;
    return 0;
}

// [Programme Name: Area of a circle estimation, My full name: Mayur Narzary, Roll no. 264057, Programme: Intg Bs-Ms Physics]
#include <iostream>
#include <random>
using namespace std;
int main() {
    double r; long N;
    cout << "Radius: "; cin >> r;
    cout << "Number of random points: "; cin >> N;
    mt19937 gen(random_device{}());
    uniform_real_distribution<double> d(-r, r);   // bounding square side 2r
    long inside = 0;
    for (long i = 0; i < N; i++) {
        double x = d(gen), y = d(gen);
        if (x * x + y * y <= r * r) inside++;
    }
    double est = (2 * r) * (2 * r) * inside / (double)N;
    double exact = 3.14159265358979 * r * r;
    cout << "Estimated area = " << est << "\nExact area     = " << exact << endl;
    return 0;
}

// [Programme Name: Volume of a sphere estimation, My full name: Mayur Narzary, Roll no. 264057, Programme: Intg Bs-Ms Physics]
#include <iostream>
#include <random>
using namespace std;
int main() {
    double r; long N;
    cout << "Radius: "; cin >> r;
    cout << "Number of random points: "; cin >> N;
    mt19937 gen(random_device{}());
    uniform_real_distribution<double> d(-r, r);   // bounding cube side 2r
    long inside = 0;
    for (long i = 0; i < N; i++) {
        double x = d(gen), y = d(gen), z = d(gen);
        if (x * x + y * y + z * z <= r * r) inside++;
    }
    double est = 8 * r * r * r * inside / (double)N;
    double exact = (4.0 / 3.0) * 3.14159265358979 * r * r * r;
    cout << "Estimated volume = " << est << "\nExact volume     = " << exact << endl;
    return 0;
}

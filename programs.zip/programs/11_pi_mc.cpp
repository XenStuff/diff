#include <iostream>
#include <random>
using namespace std;
int main() {
    long N; cout << "Number of random points: "; cin >> N;
    mt19937 gen(random_device{}());
    uniform_real_distribution<double> d(0.0, 1.0);  // unit square, quarter circle
    long inside = 0;
    for (long i = 0; i < N; i++) {
        double x = d(gen), y = d(gen);
        if (x * x + y * y <= 1.0) inside++;
    }
    cout << "Estimated pi = " << 4.0 * inside / N << endl;
    return 0;
}

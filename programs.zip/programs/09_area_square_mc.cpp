#include <iostream>
#include <random>
using namespace std;
int main() {
    double s; long N;
    cout << "Side of square: "; cin >> s;
    cout << "Number of random points: "; cin >> N;
    mt19937 gen(random_device{}());
    double L = 2 * s;                              // bounding box [0,L] x [0,L]
    uniform_real_distribution<double> d(0, L);
    double lo = s / 2, hi = lo + s;                // square placed at centre of box
    long inside = 0;
    for (long i = 0; i < N; i++) {
        double x = d(gen), y = d(gen);
        if (x >= lo && x <= hi && y >= lo && y <= hi) inside++;
    }
    double est = L * L * inside / (double)N;
    cout << "Estimated area = " << est << "\nExact area     = " << s * s << endl;
    return 0;
}
